import timm
from torch import nn
import torch
from vit_base import Attention,VisionTransformer,Block,PatchEmbed,DropPath,Mlp
import numpy as np
from sklearn.metrics import accuracy_score,recall_score,precision_score,roc_auc_score
import re
import matplotlib.pyplot as plt
from torch.optim import Adam
import os
class LoRA_ViT(VisionTransformer):
    def __init__(self, rank, device, img_size=224, patch_size=16, in_c=3, num_classes=1000, embed_dim=768, depth=12,
                 num_heads=12, mlp_ratio=4.0, qkv_bias=True, qk_scale=None, representation_size=None, distilled=False,
                 drop_ratio=0., attn_drop_ratio=0., drop_path_ratio=0., embed_layer=PatchEmbed, norm_layer=nn.LayerNorm,
                 act_layer=nn.GELU):
        super().__init__(img_size, patch_size, in_c, num_classes, embed_dim, depth, num_heads, mlp_ratio, qkv_bias,
                         qk_scale, representation_size, distilled, drop_ratio, attn_drop_ratio, drop_path_ratio,
                         embed_layer, norm_layer, act_layer)
        self.device=device
        assert rank > 0
        assert type(rank)==int
        self.dim=embed_dim
        self.depth=depth
        for params in self.parameters():
            params.requires_grad = False
        self.w_A_q = []
        self.w_B_q = []
        self.w_A_v = []
        self.w_B_v = []
        self.accuracy = []
        self.train_loss_list = []
        self.test_loss_list = []
        dpr = [x.item() for x in torch.linspace(0, drop_path_ratio, depth)]  # stochastic depth decay rule
        self.blocks = nn.Sequential(*[
            LoRA_ViT.LoRABlock(rank=rank,dim=embed_dim, num_heads=num_heads, mlp_ratio=mlp_ratio, qkv_bias=qkv_bias, qk_scale=qk_scale,
                  drop_ratio=drop_ratio, attn_drop_ratio=attn_drop_ratio, drop_path_ratio=dpr[i],
                  norm_layer=norm_layer, act_layer=act_layer)
            for i in range(depth)
        ])
        self.to(device)
    def get_pretrained_weight(self,vitmodel):
        for name, param in vitmodel.named_parameters():
            if name in self.state_dict():
                if name != 'head.weight' and name != 'head.bias':
                    self.state_dict()[name].copy_(param)
                    self.state_dict()[name].requires_grad = False
            else:
                raise ValueError("The imported model does not match the defined model")
    def save_weights_as_safetensors(self,filename):
        self.w_A_q=[]
        self.w_B_q=[]
        self.w_A_v=[]
        self.w_B_v=[]
        for i in range(self.depth):
            self.w_A_q.append(self.blocks[i].attn.w_a_linear_q.weight.cpu())
            self.w_B_q.append(self.blocks[i].attn.w_b_linear_q.weight.cpu())
            self.w_A_v.append(self.blocks[i].attn.w_a_linear_v.weight.cpu())
            self.w_B_v.append(self.blocks[i].attn.w_b_linear_v.weight.cpu())
        self.head_weight=self.head.weight.cpu()
        self.head_bias=self.head.bias.cpu()
        weights = [self.w_A_q, self.w_B_q, self.w_A_v, self.w_B_v,self.head_weight,self.head_bias]
        assert filename.endswith('.safetensors')
        torch.save(weights, filename)

    def Train_mode(self,mode:bool=True):
        for i in range(self.depth):
            self.blocks[i].attn.w_a_linear_q.weight.requires_grad=mode
            self.blocks[i].attn.w_b_linear_q.weight.requires_grad =mode
            self.blocks[i].attn.w_a_linear_v.weight.requires_grad =mode
            self.blocks[i].attn.w_b_linear_v.weight.requires_grad = mode
        self.head.weight.requires_grad=mode
        self.head.bias.requires_grad=mode
    def get_params_to_update(self):
        params_to_update = []
        for i in range(self.depth):
            params_to_update.append(self.blocks[i].attn.w_a_linear_q.weight)
            params_to_update.append(self.blocks[i].attn.w_b_linear_q.weight)
            params_to_update.append(self.blocks[i].attn.w_a_linear_v.weight)
            params_to_update.append(self.blocks[i].attn.w_b_linear_v.weight)
        params_to_update.append(self.head.weight)
        params_to_update.append(self.head.bias)
        return params_to_update
    def train_LoRA(self,dataloader,optimizer:torch.optim.Optimizer,get_loss=False,multi_label=False):
        mean_batch_loss = 0.
        # weighting=torch.tensor([0.0075,0.1635,0.1804,0.0341,2.0000,0.0228,0.0785,0.0717,0.0393,0.0856,0.1341,0.3173,0.2693,0.1971,0.0973])
        # weighting=torch.tensor([0.1635,0.1804,0.0341,2.0000,0.0228,0.0785,0.0717,0.0393,0.0856,0.1341,0.3173,0.2693,0.1971,0.0973])
        # weighting = weighting.to(self.device)
        for index, (picture, label_2) in enumerate(dataloader):
            picture, label_2 = picture.to(self.device), label_2.to(self.device)
            optimizer.zero_grad()
            output = self.forward(picture)
            # loss = nn.BCEWithLogitsLoss(weight=weighting)(output,label_2)
            if multi_label:
                loss = nn.BCEWithLogitsLoss()(output, label_2)
            else:
                loss=nn.CrossEntropyLoss()(output, label_2)
            # 加入正则化损失
            loss.backward()
            mean_batch_loss += loss.detach().cpu().numpy()
            optimizer.step()
        if get_loss:
            self.train_loss_list.append(mean_batch_loss / len(dataloader))
            print(self.train_loss_list[-1])

    def eval_LoRA(self,dataloader,multi_label=False):
        mean_batch_loss = 0.
        for _, (picture, label_2) in enumerate(dataloader):
            picture, label_2 = picture.to(self.device), label_2.to(self.device)
            output = self.forward(picture)
            probs = output.detach().clone()  # detach常用于中断输出与原模型的联系
            if multi_label:
                loss = nn.BCEWithLogitsLoss()(probs, label_2)
            else:
                loss=nn.CrossEntropyLoss()(probs,label_2)
            mean_batch_loss += loss.detach().cpu().numpy()
        # print(f'正确率{correct/total*100}%')
        self.test_loss_list.append(mean_batch_loss / len(dataloader))

    def eval_accuracy(self,dataloader,multi_label=False,is_binary=False):
        y_scores_list = []
        y_true_list = []
        y_pred_list = []
        if not multi_label:
            with torch.no_grad():
                for X_batch, y_batch in dataloader:
                    # 模型预测
                    y_scores_batch = self.forward(X_batch.to(self.device))
                    y_scores_batch = torch.softmax(y_scores_batch, dim=1)
                    y_pred = torch.argmax(y_scores_batch, dim=1)
                    if is_binary:
                        y_scores_list.append(y_scores_batch.cpu().numpy()[:, 1])
                    else:
                        y_scores_list.append(y_scores_batch.cpu().numpy())
                    y_pred_list.append(y_pred.cpu().numpy())
                    y_true_list.append(y_batch.cpu().numpy())
            y_scores = np.concatenate(y_scores_list)
            y_true = np.concatenate(y_true_list)
            y_pred = np.concatenate(y_pred_list)
            accuracy = accuracy_score(y_true, y_pred)
            # print(thresholds)
            print(f'Accuracy: {accuracy:.3f}')
            # 计算准确率
            if is_binary:
                precision = precision_score(y_true, y_pred)
                print(f'Precision: {precision:.3f}')
                # 计算召回率
                recall = recall_score(y_true, y_pred)
                print(f'Recall: {recall:.3f}')
                auc = roc_auc_score(y_true, y_scores)
                print(f'AUC: {auc:.3f}')
            else:
                precision = precision_score(y_true, y_pred, average='macro')
                print(f'Precision: {precision:.3f}')
                # 计算召回率
                recall = recall_score(y_true, y_pred, average='macro')
                print(f'Recall: {recall:.3f}')
                auc = roc_auc_score(y_true, y_scores, average='macro', multi_class='ovr')
                print(f'AUC: {auc:.3f}')
        else:
            print('multi_label model need other test method')
            self.eval_Adalora(dataloader=dataloader,multi_label=multi_label)

    def plot_and_save(self, folder_path):
        # 创建文件夹
        if not os.path.exists(folder_path):
            os.makedirs(folder_path)
        # 绘制图像
        fig, ax1 = plt.subplots()
        ax1.plot(self.train_loss_list, label='Train Loss', color='tab:blue')
        ax1.plot(self.test_loss_list, label='Test Loss', color='tab:orange')
        ax1.set_xlabel('Epochs')
        ax1.set_ylabel('Loss', color='black')
        ax1.tick_params(axis='y', labelcolor='black')
        plt.title('Loss')
        fig.legend(loc="upper right")
        # 保存图像
        plt.savefig(os.path.join(folder_path, 'plot.png'))
        plt.show()
        plt.close()
        with open(os.path.join(folder_path, 'data.txt'), 'w') as f:
            f.write("\n\nTrain Loss:\n")
            f.write("\n".join(map(str, self.train_loss_list)))
            f.write("\n\nTest Loss:\n")
            f.write("\n".join(map(str, self.test_loss_list)))
    def load_weights_from_safetensors(self, filename):
        assert filename.endswith('.safetensors')
        weights = torch.load(filename)
        self.w_A_q = weights[0]
        self.w_B_q = weights[1]
        self.w_A_v = weights[2]
        self.w_B_v = weights[3]
        self.head_weight=weights[4]
        self.head_bias=weights[5]
        for i in range(self.depth):
            self.blocks[i].attn.w_a_linear_q.weight=torch.nn.Parameter(self.w_A_q[i])
            self.blocks[i].attn.w_b_linear_q.weight=torch.nn.Parameter(self.w_B_q[i])
            self.blocks[i].attn.w_a_linear_v.weight=torch.nn.Parameter(self.w_A_v[i])
            self.blocks[i].attn.w_b_linear_v.weight=torch.nn.Parameter(self.w_B_v[i])
        self.head.weight=torch.nn.Parameter(self.head_weight)
        self.head.bias=torch.nn.Parameter(self.head_bias)
    def load_weights_from_list(self,list:list):
        self.list=list
        self.switch_weights(0)

    def switch_weights(self,num):
        file_path = self.list[num]
        information=re.split(r'[._]', file_path.split("/")[-1])
        r = int(information[3])
        self.rank=r
        self.num_classes=int(information[4])
        self.reset_classifier(num_classes=self.num_classes)
        self.load_weights_from_safetensors(file_path)

    def forward(self, x):
        return super().forward(x)


    class LoRAAttention(Attention):
        def __init__(self, dim, num_heads=8, qkv_bias=True, qk_scale=None, attn_drop_ratio=0., proj_drop_ratio=0.,
                     rank=4):
            super().__init__(dim, num_heads, qkv_bias, qk_scale, attn_drop_ratio, proj_drop_ratio)
            self.rank = rank
            self.w_a_linear_q = nn.Linear(dim, rank, bias=False)
            self.w_b_linear_q = nn.Linear(rank, dim, bias=False)
            self.w_a_linear_v = nn.Linear(dim, rank, bias=False)
            self.w_b_linear_v = nn.Linear(rank, dim, bias=False)
            self.w_a_linear_q.weight=nn.Parameter(torch.normal(mean=0.0,std=0.02,size=(rank,dim),requires_grad=True))
            self.w_b_linear_q.weight = nn.Parameter(torch.normal(mean=0.0,std=0.02,size=(dim,rank),requires_grad=True))
            self.w_a_linear_v.weight = nn.Parameter(torch.normal(mean=0.0,std=0.02,size=(rank,dim),requires_grad=True))
            self.w_b_linear_v.weight = nn.Parameter(torch.normal(mean=0.0,std=0.02,size=(dim,rank),requires_grad=True))
            # self.w_a_linear_q.weight.requires_grad = True
            # self.w_b_linear_q.weight.requires_grad = True
            # self.w_a_linear_v.weight.requires_grad = True
            # self.w_b_linear_v.weight.requires_grad = True
        def forward(self, x):
            B, N, C = x.shape
            qkv = self.qkv(x).reshape(B, N, 3, self.num_heads, C // self.num_heads).permute(2, 0, 3, 1, 4)
            q, k, v = qkv[0], qkv[1], qkv[2]
            q_res=self.w_b_linear_q(self.w_a_linear_q(x)).reshape(B, N,self.num_heads, C // self.num_heads).permute(0, 2, 1, 3)
            v_res=self.w_b_linear_v(self.w_a_linear_v(x)).reshape(B, N,self.num_heads, C // self.num_heads).permute(0, 2, 1, 3)
            attn = ((q+q_res) @ k.transpose(-2, -1)) * self.scale
            attn = attn.softmax(dim=-1)
            attn = self.attn_drop(attn)
            x = (attn @ (v+v_res)).transpose(1, 2).reshape(B, N, C)
            x = self.proj(x)
            x = self.proj_drop(x)
            return x

    class LoRABlock(Block):
        def __init__(self,
                     dim,
                     rank,
                     num_heads,
                     mlp_ratio=4.,
                     qkv_bias=True,
                     qk_scale=None,
                     drop_ratio=0.,
                     attn_drop_ratio=0.,
                     drop_path_ratio=0.,
                     act_layer=nn.GELU,
                     norm_layer=nn.LayerNorm):
            super(LoRA_ViT.LoRABlock, self).__init__(dim,num_heads)
            self.attn=LoRA_ViT.LoRAAttention(rank=rank,dim=dim, num_heads=num_heads, qkv_bias=qkv_bias, qk_scale=qk_scale,
                              attn_drop_ratio=attn_drop_ratio, proj_drop_ratio=drop_ratio)

#下面进行测试

if __name__=='__main__':

    import importlib
    import timm
    import os
    from torchvision.transforms import ToTensor,Compose,Resize,RandomHorizontalFlip,Normalize
    import torch
    from torch.utils.data import DataLoader, Dataset
    from PIL import Image
    import warnings
    import torch.nn.functional as F
    #忽视警告
    warnings.filterwarnings('ignore')
    #加载数据集
    class LabeledImage(Dataset):
        def __init__(self, image_path_list, label_list, num_classes=2):
            self.image_path_list = image_path_list
            self.label_list = label_list
            self.num_classes = num_classes
            self.transform = None

        def __len__(self):
            return len(self.image_path_list)

        def __getitem__(self, index):
            image_path = self.image_path_list[index]
            label1=self.label_list[index]
            label2 = torch.zeros(self.num_classes)
            if type(label1) == int or str:
                label2[int(label1)] = 1.
            else:
                label1 = torch.tensor(float(self.label_list[index]))
                for k in label1:
                    label2[int(k)] = 1.
            image = Image.open(image_path)
            image = image.convert('RGB')  # 转换成灰度图/彩色图
            image_tensor = self.transform(image)
            return image_tensor, label2


    class cxp_dataset(LabeledImage):
        def __init__(self, image_path_list, label_list, num_classes=2):
            super().__init__(image_path_list, label_list, num_classes=num_classes)
            self.transform = Compose([ToTensor(), Resize(size=(224, 224)),
                                      RandomHorizontalFlip(p=0.5),
                                      Normalize(mean=[0.485, 0.456, 0.406],
                                                std=[0.229, 0.224, 0.225]),  # 为什么灰度图有三色值？这里先当RGB处理了
                                      ])  # 这是使用ImageNet的均值和标准差


    # 划分数据集
    def get_dataloader(folder_path, num_classes=2):
        image_path_list = []
        label_list = []
        # 遍历文件夹中的所有图片文件
        for filename in os.listdir(folder_path):
            if filename.endswith(".jpg") or filename.endswith(".png"):
                image_path = os.path.join(folder_path, filename)
                image_path_list.append(image_path)
            label = list(filename.strip('.png').strip('.jpg'))[-1]
            label_list.append(label)
        return cxp_dataset(image_path_list, label_list, num_classes=num_classes)


    # we only support multi-melo with timm ViT models
    #开始预测
    # task_index = 0
    # img = torch.randn(1, 3, 224, 224)
    # melo.swith_lora(task_index)
    # melos_out = melo(img)
    # print(melos_out)
    #加载数据集
    weightInfo = {
       # "small":"WinKawaks/vit-small-patch16-224",
       "base": "vit_base_patch16_224",
    }
    #weightInfo={'base':r"D:\桌面\大创\tool\vit-base-patch16-224"}
    model = timm.create_model(weightInfo["base"], pretrained=True)
    cxp_path=[r"D:\桌面\大创\CXR数据集"]
    dataset_cxp=get_dataloader(cxp_path[0])
    batch_size=40
    now_cxp_dataloader=DataLoader(dataset_cxp,batch_size=batch_size,shuffle=True)
    model2 = LoRA_ViT(rank=4, num_classes=2,device=torch.device("cuda" if torch.cuda.is_available() else "cpu"))
    assert model2.dim == model.blocks[0].attn.proj.in_features
    for name, param in model.named_parameters():
        if name in model2.state_dict():
            if name!='head.weight' and name!='head.bias':
                model2.state_dict()[name].copy_(param)
                model2.state_dict()[name].requires_grad = False
        else:
            raise ValueError("The imported model does not match the defined model")

    model2.save_weights_as_safetensors(r"D:\Latex\try_base_lora_4_2.safetensors")
    model2.load_weights_from_list([r"D:\Latex\try_base_lora_4_2.safetensors"])
    # 切换训练环境
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model2.to(device)
    params_to_update=model2.get_params_to_update()
    model2.train_LoRA(params_to_update=params_to_update,dataloader=now_cxp_dataloader,get_loss=True)
    model2.eval_LoRA(dataloader=now_cxp_dataloader)
    model2.plot_and_save(folder_path=r"D:\桌面\大创\try")